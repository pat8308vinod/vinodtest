//js for nav fixed on call
window.onscroll = function() {myFunction()};

var header = document.getElementById("myHeader");
var sticky = header.offsetTop;

function myFunction() {
  if (window.pageYOffset > sticky) {
    header.classList.add("nav-sticky");
  } else {
    header.classList.remove("nav-sticky");
  }
}

$(document).ready(function(){
  $('.navbar-toggler').click(function(){
    $("#btn1").toggleClass("btnshowhide");
  });
});